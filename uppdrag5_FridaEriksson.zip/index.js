//level up+++
//så att användare kan göra yes/no val. Körde npm install prompt-sync i terminalen först
const prompt = require('prompt-sync')();

//funktion för välkomstfras
function opening() {
    console.log('');
    console.log('Welcome to the HumorHub!');
    console.log('We serve all the best programming jokes, let me tell you one:');
    console.log('');
}
//Funktion för att slumpa samt hålla reda på vilka skämt som redan dragits
function slumpa(previousJokes) {
    let index;
    do {
        index = Math.floor(Math.random() * 10);
    } while (previousJokes.includes(index));
    previousJokes.push(index);
    return index;
}

//skämten
const programmingJokes = [
    "How do JavaScript developers stay in shape? They do a lot of callbacks.",    
    "What do programmers do when they're hungry? They grab a byte.",
    "How do you comfort a JavaScript developer? You console them.",
    "Why did the developer go broke? Because he used up all his cache.",
    "Why did the JavaScript developer go missing? Because he didn't know when to return.",
    "Why did the computer go to the doctor? Because it had a virus!",
    "Why do JavaScript developers wear glasses? Because they don't see sharp (C#.)",
    "What did the router say to the doctor? It hurts when IP.",
    "What is a programmer's first words when they wake up in the morning? Hello, World!",
    "Why was the computer cold? It left its Windows open."  
];
//funktion för att slumpa ut skämten som också håller koll på vilket som redan dragits
function randomJoke(jokes, previousJokes) {
    let index = slumpa(previousJokes);
    console.log(jokes[index]);
}
//funktion för användare att lägga in eget skämt
function addJoke(jokes) {
    let newJoke = prompt('Enter your own programming joke: ');
    jokes.push(newJoke);
    console.log('Haha! That was a gr8 joke, thank you!');
    return false;
}
//funktion för avslut
function closing() {
    console.log('');
    console.log('Thank you for using the HumorHub!');
    console.log('Have a nice day!');
}
//anropar funktionerna, välkomstmeddelande
opening();

let continueJokes = true;
let jokeCount = 0;
let previousJokes = [];

randomJoke(programmingJokes, previousJokes);
    jokeCount++; //första skämtet dras
//frågar om användaren vill höra ett till skämt, om nej avslutas programmet
while (continueJokes) {
    let answer = prompt('Do you want to hear another programming joke? (yes/no): ').toLowerCase();
    if (answer !== 'yes') {
        continueJokes = false;
    } else  {
    randomJoke(programmingJokes, previousJokes);
    jokeCount++;
//frågar om användaren vill lägga till eget skämt, om nej avslutas programmet, om ja får användaren skriva in sitt skämt sen avslutas programmet.
        answer = prompt('Would you like to humor us with one of your own favorite jokes? (yes/no): ').toLowerCase();
        if (answer === 'yes') {
            addJoke(programmingJokes);
            continueJokes = false;
        }
    }
}
//anropar avslut
closing();