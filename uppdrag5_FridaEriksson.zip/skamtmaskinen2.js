//level up+
//så att användare kan göra yes/no val.
const prompt = require('prompt-sync')();
//funktion för välkomstfras
function opening() {
    console.log('')
    console.log('Welcome to the HumorHub!')
    console.log('We serve all the best programming jokes, let me tell you one:')
    console.log('')
}
//Funktion för att slumpa 
function slumpa() {
    return Math.floor(Math.random() * 10);
}
//skämten
const programmingJokes = [
    "How do JavaScript developers stay in shape? They do a lot of callbacks.",    
    "What do programmers do when they're hungry? They grab a byte.",
    "How do you comfort a JavaScript developer? You console them.",
    "Why did the developer go broke? Because he used up all his cache.",
    "Why did the JavaScript developer go missing? Because he didn't know when to return.",
    "Why did the computer go to the doctor? Because it had a virus!",
    "Why do JavaScript developers wear glasses? Because they don't see sharp (C#.)",
    "What did the router say to the doctor? It hurts when IP.",
    "What is a programmers first words when they wake up in the morning? Hello, World!",
    "Why was the computer cold? It left its Windows open."  
];
//funktion för att slumpa ut skämten 
function randomJoke(jokes) {
    let index = slumpa();
    console.log(jokes[index]);
}

//funktion för avslut
  function closing() {
    console.log('');
    console.log('Thank you for using the HumorHub!');
    console.log('Have a nice day!')
  }
////////////////////////////////////////////////////////////////////////////////////////////////

//anropar funktionerna
  opening();

// loop för användaren att fortsätta höra flera skämt genom att svara yes, eller avsluta genom att svara no
  let continueJokes = true;

  while (continueJokes) {
    randomJoke(programmingJokes);
    
    let answer = prompt('Do you want to hear another programming joke? (yes/no): ').toLowerCase();
    if (answer !== 'yes') {
        continueJokes = false;
    }
  }

  closing();